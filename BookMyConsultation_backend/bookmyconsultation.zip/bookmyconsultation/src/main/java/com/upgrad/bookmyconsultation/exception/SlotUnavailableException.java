package com.upgrad.bookmyconsultation.exception;

public class SlotUnavailableException extends RuntimeException {

}
